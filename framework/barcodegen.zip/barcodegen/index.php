<?php
header('Location: html/index.php');
?>