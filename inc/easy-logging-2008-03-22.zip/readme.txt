PHP logging class:
Visit: http://urbanoalvarez.es/blog/2008/03/21/php-logging-class/
For full support

Developed by Alejandro U Alvarez.
Released under the GPL Licence (Free for personal and commercial use, but please, provdide link)

Features

This are the things the logging class will do:

    * Store different security levels (Low, Medium, and High)
    * Get the real visitor's IP for every log entry
    * Allow several optional parameters, such as message, priority, page...
    * Easily translated into other languages
    * TABLE_LOGS.sql.txt - This file creates the table 'log'

And this is a screenshot of the log page in action (Or go to the sample page and take a look)
Screenshot of log
Class files and code:

The following files are the really important files:

    * log.class.php - This file contains the logging functions.
    * database.php - This file handles database connection and queries.
    * config.php - This file defines the configuration constants used for database queries. You should only edit this file.
    * logInit.php - This file includes all necessary files and initializes the classes storing them in the appropriate objects

Also, for the example, there are two other files: 'log.php' and 'test.php'. The log.php file shows a sample log, and the test.php shows a sample usage page.
Log in use:

I've set up a test page and a log page. In the test page there are several "common" stuff that you would normally log (A login form, an edit form, and a contact form)

I would recommend that you check those out, in any order you like, and experiment with the different options you'll see in the test page

Usage:

The usage of this logging class is VERY very simple, First of all download the zip with the needed files.
Then you must fill in all the variables in the config.php page.
Once all is configured, upload it to your server, and insert the following code in all the pages you will like to log activity:

 
< ?php
//Initialize logging clases
include('logInit.php');
//
?>
 

This is the initialization of the logging object and all other needed stuff.

The logging function is:

 
< ?php
$log->logg('page','message','priority','class','mail');
?>
 

Parameters explanation:

    * Page: This is the page where the log is placed. Set to 1 and it will be automatically detected.
    * Message: This is the message you want to have the log store. You can have some preset messages which are stored in the log.class.php file. Set to 1 to have a preset message stored.
    * Priority: This is the priority or Importance of the log entry. Values can be: High,Medium,Low.
    * Class: This is the class you want the log entry to have. Values are: Red, Danger, Yellow, Green, and Blue.
    * Mail: This setting can be yes or no. If it is not specified it will be set to "no".

You can edit the list of pre-set important pages in the file log.class.php, which is strongly recommended.


If you improve this script, or you find any bugs, report them using the comments please!
And remember, for any doubt or problem you have with the usage of this class, comment here and leave an email in the field email so I can answer you!

http://urbanoalvarez.es/blog/2008/03/21/php-logging-class/